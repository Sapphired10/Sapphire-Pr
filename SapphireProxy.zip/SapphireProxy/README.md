# 💎 Sapphire Proxy v2.0
Minecraft Bedrock MITM cheat client — Android APK

## Build Requirements
- Android Studio Hedgehog 2023.1.1+
- JDK 17
- Android SDK 34

## Build Steps
1. Open this folder in Android Studio
2. File → Sync Project with Gradle Files
3. Build → Build Bundle(s)/APK(s) → Build APK(s)
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Features
- 40+ modules (Combat, Movement, Visual, World, Player, Exploit)
- `/.command` chat-based command system (type in-game or via console tab)
- PS4/PS5/Console LAN proxy spoofing
- Glass morphism animated UI
- Foreground service — stays alive background
- Live packet logger

## Command List
Type `/.help` in-game or in the Console tab

## Setup (PS4/PS5)
1. Install APK on Android phone
2. Connect phone + console to same WiFi
3. Enter server IP → tap CONNECT
4. Minecraft → Play → Servers → LAN → "Sapphire Proxy"

## Module Keybinds (chat commands)
- `/.ka` — KillAura
- `/.esp` — ESP  
- `/.fly` — Fly
- `/.nf` — NoFall
- `/.vel` — Velocity
- `/.speed 2.0` — Speed multiplier
- `/.tp x y z` — Teleport
