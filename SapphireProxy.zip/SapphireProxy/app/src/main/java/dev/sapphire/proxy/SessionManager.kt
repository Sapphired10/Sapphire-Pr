package dev.sapphire.proxy

import io.netty.bootstrap.Bootstrap
import io.netty.channel.*
import io.netty.channel.socket.nio.NioDatagramChannel
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec
import org.cloudburstmc.protocol.bedrock.packet.*

/**
 * One SessionManager per connected client (console/mobile).
 * Downstream = client ↔ us.  Upstream = us ↔ real server.
 * All packets pass through PacketHandler for module processing.
 */
class SessionManager(
    private val downstream: Channel,
    private val remoteHost: String,
    private val remotePort: Int,
    private val handler: PacketHandler,
    private val codec: BedrockCodec,
    private val state: SessionState
) : ChannelInboundHandlerAdapter() {

    private var upstream: Channel? = null

    override fun channelActive(ctx: ChannelHandlerContext) {
        connectUpstream(ctx.channel().eventLoop())
    }

    private fun connectUpstream(loop: EventLoop) {
        Bootstrap()
            .group(loop)
            .channelFactory(RakChannelFactory.client(NioDatagramChannel::class.java))
            .handler(object : ChannelInboundHandlerAdapter() {
                // Packets arriving from the real server → forward to our client
                override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
                    if (msg is BedrockPacket) {
                        val out = handler.handleSTC(msg)
                        if (out != null) downstream.writeAndFlush(out)
                    }
                }
                override fun channelInactive(ctx: ChannelHandlerContext) {
                    downstream.close()
                }
            })
            .connect(remoteHost, remotePort)
            .addListener { f ->
                upstream = (f as ChannelFuture).channel()
            }
    }

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        if (msg !is BedrockPacket) return

        val outPackets = handler.handleCTS(msg)
        outPackets.forEach { upstream?.writeAndFlush(it) }

        // Pending teleport from /.tp command
        state.pendingTeleport?.let { (x, y, z) ->
            state.pendingTeleport = null
            val tp = MovePlayerPacket().apply {
                runtimeEntityId = 1L
                position = Vector3f.from(x, y, z)
                rotation = org.cloudburstmc.math.vector.Vector3f.from(0f, 0f, 0f)
                isOnGround = true
            }
            upstream?.writeAndFlush(tp)
        }

        // Pending injected chat from /.say command
        state.pendingInjectChat?.let { msg2 ->
            state.pendingInjectChat = null
            val chat = TextPacket().apply {
                type = TextPacket.Type.CHAT
                needsTranslation = false
                sourceName = ""
                message = msg2
                xuid = ""
            }
            downstream.writeAndFlush(chat)
        }
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        upstream?.close()
        state.connected = false
        state.updateStats()
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        cause.printStackTrace()
        ctx.close()
    }
}
