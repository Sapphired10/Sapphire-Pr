package dev.sapphire.modules.combat
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
class Velocity : Module("Velocity", Category.COMBAT, "Reduce knockback (0=none)", key = "vel") {
    var horizontalFactor: Float = 0.0f; var verticalFactor: Float = 1.0f
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? {
        if (packet is SetEntityMotionPacket) {
            val o = packet.motion
            packet.motion = Vector3f.from(o.x * horizontalFactor, o.y * verticalFactor, o.z * horizontalFactor)
        }
        return packet
    }
}