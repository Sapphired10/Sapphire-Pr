package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.*
class HighJump : Module("HighJump", Category.MOVEMENT, "Boost jump height via motion") {
    var boost: Float = 2.0f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket && packet.inputData.contains(PlayerAuthInputData.JUMPING)) {
            packet.position = org.cloudburstmc.math.vector.Vector3f.from(packet.position.x, packet.position.y + boost, packet.position.z)
        }
        return listOf(packet)
    }
}