package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.*
class Sprint : Module("Sprint", Category.MOVEMENT, "Always-sprint flag injection") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) packet.inputData.add(PlayerAuthInputData.SPRINTING)
        return listOf(packet)
    }
}