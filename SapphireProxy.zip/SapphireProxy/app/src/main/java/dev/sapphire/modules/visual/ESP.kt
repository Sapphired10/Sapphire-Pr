package dev.sapphire.modules.visual
import dev.sapphire.SapphireApp
import dev.sapphire.modules.Module
import dev.sapphire.proxy.TrackedEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.cloudburstmc.protocol.bedrock.packet.*
class ESP : Module("ESP", Category.VISUAL, "Track and display all entity positions", key = "esp") {
    private val _entities = MutableStateFlow<List<TrackedEntity>>(emptyList())
    val entities: StateFlow<List<TrackedEntity>> = _entities
    override fun onTick() { _entities.value = SapphireApp.entityTracker.entities.values.toList() }
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}