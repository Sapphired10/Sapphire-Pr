package dev.sapphire.ui.screens
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sapphire.proxy.ProxyStats
import dev.sapphire.ui.components.*
import dev.sapphire.ui.theme.*
@Composable
fun HomeScreen(stats: ProxyStats, serverIp: String, serverPort: String, onIpChange: (String) -> Unit, onPortChange: (String) -> Unit, onConnect: () -> Unit, onDisconnect: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Spacer(Modifier.height(8.dp))
            Column {
                Text("SAPPHIRE", style = MaterialTheme.typography.headlineLarge.copy(
                    brush = Brush.horizontalGradient(listOf(SapphirePrimary, SapphireSecondary)),
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp))
                Text("PROXY  v2.0", style = MaterialTheme.typography.bodyMedium.copy(letterSpacing = 6.sp, color = TextMuted))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusDot(stats.connected)
                Text(if (stats.connected) "ACTIVE — LAN BROADCASTING" else "OFFLINE",
                    style = MaterialTheme.typography.labelSmall.copy(color = if (stats.connected) SapphireSuccess else TextMuted, letterSpacing = 2.sp, fontWeight = FontWeight.Bold))
            }
            GlassCard(glowColor = if (stats.connected) SapphireSuccess else SapphirePrimary) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("TARGET SERVER", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, letterSpacing = 2.sp))
                    OutlinedTextField(serverIp, onIpChange, Modifier.fillMaxWidth(), enabled = !stats.connected, label = { Text("Server IP") },
                        leadingIcon = { Icon(Icons.Default.Dns, null, tint = SapphirePrimary) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SapphirePrimary, unfocusedBorderColor = SapphireDivider, focusedLabelColor = SapphirePrimary, cursorColor = SapphireSecondary),
                        shape = RoundedCornerShape(12.dp))
                    OutlinedTextField(serverPort, onPortChange, Modifier.fillMaxWidth(), enabled = !stats.connected, label = { Text("Port") },
                        leadingIcon = { Icon(Icons.Default.SettingsInputHdmi, null, tint = SapphirePrimary) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SapphirePrimary, unfocusedBorderColor = SapphireDivider, focusedLabelColor = SapphirePrimary, cursorColor = SapphireSecondary),
                        shape = RoundedCornerShape(12.dp))
                    Button(onClick = if (stats.connected) onDisconnect else onConnect, Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (stats.connected) SapphireDanger else SapphirePrimary),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(if (stats.connected) Icons.Default.Stop else Icons.Default.PlayArrow, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (stats.connected) "DISCONNECT" else "CONNECT + START LAN", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }
            if (stats.connected) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("PING", "${stats.pingMs}ms", SapphireSecondary, Modifier.weight(1f))
                    StatCard("C→S", "${stats.ctsPackets}", SapphirePrimary, Modifier.weight(1f))
                    StatCard("LAN", "LIVE", SapphireSuccess, Modifier.weight(1f))
                }
            }
            GlassCard(glowColor = SapphireAccentPurp.copy(0.4f)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("QUICK COMMANDS", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, letterSpacing = 2.sp))
                    Spacer(Modifier.height(4.dp))
                    val cmds = listOf("/.help — list all commands","/.ka — toggle KillAura","/.fly — toggle Fly","/.esp — toggle ESP","/.speed 2.0 — set speed","/.tp x y z — teleport","/.modules — list all modules")
                    cmds.forEach { Text(it, style = MaterialTheme.typography.bodyMedium.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 11.sp), color = TextSecondary) }
                }
            }
        }
    }
}
@Composable
private fun StatCard(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    GlassCard(glowColor = color, modifier = modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge.copy(color = color, fontWeight = FontWeight.Bold), maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, letterSpacing = 1.5.sp))
        }
    }
}
@Composable
private fun StatusDot(active: Boolean) {
    val inf = rememberInfiniteTransition(label = "dot")
    val scale by inf.animateFloat(1f, 1.35f, infiniteRepeatable(tween(700), androidx.compose.animation.core.RepeatMode.Reverse), label = "s")
    Canvas(Modifier.size(8.dp).then(if (active) Modifier.scale(scale) else Modifier)) { drawCircle(if (active) SapphireSuccess else TextMuted) }
}
