package dev.sapphire.proxy

import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.net.*

/**
 * Listens on UDP 19132 for RakNet UnconnectedPing (0x01) from consoles/mobile
 * and replies with a crafted UnconnectedPong (0x1c) that lists this device
 * as a LAN Minecraft server. PS4/PS5/Switch/Xbox all use this discovery method.
 */
class LanBroadcaster(
    var motd: String = "§bSapphire Proxy§r",
    var listenPort: Int = 19132,
    var protocolVersion: Int = 630
) {
    private var job: Job? = null
    private val serverId = System.currentTimeMillis()

    companion object {
        private val RAKNET_MAGIC = byteArrayOf(
            0x00, 0xff.toByte(), 0xff.toByte(), 0x00,
            0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(),
            0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(),
            0x12, 0x34, 0x56, 0x78
        )
    }

    private fun buildPong(): ByteArray {
        val info = "MCPE;$motd;$protocolVersion;1.21.0;0;20;$serverId;Sapphire;Survival;1;$listenPort;19133;"
        val infoBytes = info.toByteArray(Charsets.UTF_8)
        val buf = ByteArrayOutputStream()
        buf.write(0x1c)                             // ID_UNCONNECTED_PONG
        writeLong(buf, System.currentTimeMillis())  // timestamp
        writeLong(buf, serverId)                    // server GUID
        buf.write(RAKNET_MAGIC)
        buf.write((infoBytes.size shr 8) and 0xFF)
        buf.write(infoBytes.size and 0xFF)
        buf.write(infoBytes)
        return buf.toByteArray()
    }

    private fun writeLong(buf: ByteArrayOutputStream, value: Long) {
        for (i in 7 downTo 0) buf.write(((value shr (i * 8)) and 0xFF).toInt())
    }

    fun start(scope: CoroutineScope) {
        job?.cancel()
        job = scope.launch(Dispatchers.IO) {
            val socket = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                soTimeout = 500
                bind(InetSocketAddress(listenPort))
            }
            try {
                val recvBuf = ByteArray(1500)
                while (isActive) {
                    val pkt = DatagramPacket(recvBuf, recvBuf.size)
                    try {
                        socket.receive(pkt)
                    } catch (_: SocketTimeoutException) { continue }

                    // 0x01 = UnconnectedPing
                    if (pkt.length > 0 && recvBuf[0] == 0x01.toByte()) {
                        val pong = buildPong()
                        socket.send(DatagramPacket(pong, pong.size, pkt.address, pkt.port))
                    }
                }
            } finally {
                runCatching { socket.close() }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    fun updateMotd(newMotd: String) { motd = newMotd }
}
