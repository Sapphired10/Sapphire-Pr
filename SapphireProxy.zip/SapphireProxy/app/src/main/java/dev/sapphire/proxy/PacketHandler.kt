package dev.sapphire.proxy

import dev.sapphire.SapphireApp
import dev.sapphire.command.CommandEngine
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket

class PacketHandler(
    private val state: SessionState,
    private val commandEngine: CommandEngine
) {
    private val mgr = SapphireApp.moduleManager
    private val tracker = SapphireApp.entityTracker

    // Client → Server
    fun handleCTS(packet: BedrockPacket): List<BedrockPacket> {
        state.ctsCount++
        state.updateStats()

        // Command interception — TextPacket starting with "/."
        if (packet is TextPacket) {
            val msg = packet.message ?: ""
            if (msg.startsWith("/.")) {
                // Feed to command engine, DROP the packet (don't forward to server)
                commandEngine.handle(msg)
                return emptyList()
            }
        }

        if (state.requestDisconnect) {
            state.requestDisconnect = false
            return emptyList()
        }

        // Run through active modules
        var packets = mutableListOf(packet)
        for (module in mgr.enabled) {
            val result = mutableListOf<BedrockPacket>()
            for (pkt in packets) result.addAll(module.onClientToServer(pkt))
            packets = result
        }

        // Log if PacketLogger active
        if (mgr.get("PacketLogger")?.enabled == true) {
            packets.forEach {
                state.pushLog(LogEntry("C→S", it::class.simpleName ?: "Unknown"))
            }
        }

        // Tick all modules once per auth input
        mgr.tickAll()

        return packets
    }

    // Server → Client
    fun handleSTC(packet: BedrockPacket): BedrockPacket? {
        state.stcCount++
        tracker.handle(packet)

        var current: BedrockPacket? = packet
        for (module in mgr.enabled) {
            current = current?.let { module.onServerToClient(it) }
        }

        if (mgr.get("PacketLogger")?.enabled == true && current != null) {
            state.pushLog(LogEntry("S→C", current::class.simpleName ?: "Unknown"))
        }

        return current
    }
}
