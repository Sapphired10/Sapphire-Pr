package dev.sapphire.modules.misc
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class PacketLogger : Module("PacketLogger", Category.MISC, "Log all packets to Logs screen") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}