package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Blink : Module("Blink", Category.MOVEMENT, "Buffer then flush packets for lag abuse") {
    var blinkDuration: Int = 40; private val buffer = mutableListOf<BedrockPacket>(); private var tick = 0
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        buffer.add(packet); tick++
        if (tick >= blinkDuration) { tick = 0; val f = buffer.toList(); buffer.clear(); return f }
        return emptyList()
    }
    override fun onDisable() { buffer.clear(); tick = 0 }
}