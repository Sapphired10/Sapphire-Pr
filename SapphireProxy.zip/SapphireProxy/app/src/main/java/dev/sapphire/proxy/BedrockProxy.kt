package dev.sapphire.proxy

import dev.sapphire.command.CommandEngine
import io.netty.bootstrap.Bootstrap
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.*
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.nio.NioDatagramChannel
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption
import org.cloudburstmc.protocol.bedrock.BedrockPong
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec
import org.cloudburstmc.protocol.bedrock.codec.v630.Bedrock_v630
import org.cloudburstmc.protocol.bedrock.netty.initializer.BedrockServerInitializer

/**
 * The MITM proxy server.
 * Listens on listenPort (19132) with a RakNet server.
 * For each connecting client, spawns a SessionManager that connects upstream.
 */
class BedrockProxy(
    val listenPort: Int = 19132,
    val remoteHost: String,
    val remotePort: Int = 19132,
    val state: SessionState
) {
    // Swap codec here for different Bedrock versions — Bedrock_v630 = 1.21.x
    val codec: BedrockCodec = Bedrock_v630.CODEC

    private val bossGroup  = NioEventLoopGroup(1)
    private val workerGroup = NioEventLoopGroup(4)
    private var serverChannel: Channel? = null

    fun start() {
        val commandEngine = CommandEngine(state)

        val pong = BedrockPong().apply {
            edition          = "MCPE"
            motd             = "§bSapphire Proxy"
            subMotd          = "github.com/sapphire"
            playerCount      = 0
            maximumPlayerCount = 20
            gameType         = "Survival"
            protocolVersion  = codec.protocolVersion
            version          = codec.minecraftVersion
        }

        serverChannel = ServerBootstrap()
            .group(bossGroup, workerGroup)
            .channelFactory(RakChannelFactory.server(NioDatagramChannel::class.java))
            .option(RakChannelOption.RAK_ADVERTISEMENT, pong.toByteBuf())
            .option(RakChannelOption.RAK_MAX_CHANNELS, 1)
            .childHandler(object : BedrockServerInitializer() {
                override fun initChannel(channel: Channel) {
                    super.initChannel(channel)
                    val handler = PacketHandler(state, commandEngine)
                    channel.pipeline().addLast(
                        SessionManager(channel, remoteHost, remotePort, handler, codec, state)
                    )
                }
            })
            .bind("0.0.0.0", listenPort)
            .sync()
            .channel()

        state.connected = true
        state.remoteHost = remoteHost
        state.remotePort = remotePort
        state.updateStats()
    }

    fun stop() {
        serverChannel?.close()
        bossGroup.shutdownGracefully()
        workerGroup.shutdownGracefully()
        state.connected = false
        state.updateStats()
    }
}
