package dev.sapphire.ui
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.sapphire.ui.screens.*
import dev.sapphire.ui.theme.*
import dev.sapphire.ui.viewmodel.MainViewModel
sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home     : Screen("home",    "Home",    Icons.Default.Home)
    object Modules  : Screen("modules", "Modules", Icons.Default.Extension)
    object Console  : Screen("console", "Console", Icons.Default.Terminal)
    object Logs     : Screen("logs",    "Logs",    Icons.Default.Article)
    object Settings : Screen("settings","Settings",Icons.Default.Settings)
}
class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { SapphireTheme { SapphireApp(vm) } }
    }
}
@Composable
fun SapphireApp(vm: MainViewModel) {
    val screens = listOf(Screen.Home, Screen.Modules, Screen.Console, Screen.Logs, Screen.Settings)
    var cur by remember { mutableStateOf("home") }
    val stats  by vm.stats.collectAsStateWithLifecycle()
    val logs   by vm.logs.collectAsStateWithLifecycle()
    val ip     by vm.serverIp.collectAsStateWithLifecycle()
    val port   by vm.serverPort.collectAsStateWithLifecycle()
    val sets   by vm.settings.collectAsStateWithLifecycle()
    Scaffold(containerColor = SapphireDeep, contentWindowInsets = WindowInsets.navigationBars,
        bottomBar = {
            NavigationBar(containerColor = SapphireDeep.copy(0.97f), tonalElevation = 0.dp) {
                screens.forEach { s ->
                    val sel = cur == s.route
                    NavigationBarItem(sel, { cur = s.route }, icon = { Icon(s.icon, null) },
                        label = { Text(s.label, fontSize = 10.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, letterSpacing = 0.4.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = SapphirePrimary, selectedTextColor = SapphirePrimary, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted, indicatorColor = SapphirePrimary.copy(0.15f)))
                }
            }
        }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(cur, label = "nav", transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(140)) }) { route ->
                when (route) {
                    "home"     -> HomeScreen(stats, ip, port, { vm.serverIp.value = it }, { vm.serverPort.value = it }, { vm.connect() }, { vm.disconnect() })
                    "modules"  -> ModulesScreen(dev.sapphire.SapphireApp.moduleManager)
                    "console"  -> CommandScreen(vm.commandOutput) { vm.sendCommand(it) }
                    "logs"     -> LogsScreen(logs) { vm.state.clearLogs() }
                    "settings" -> SettingsScreen(sets) { vm.settings.value = it }
                }
            }
        }
    }
}
