package dev.sapphire.ui.viewmodel
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.sapphire.SapphireApp
import dev.sapphire.command.CommandEngine
import dev.sapphire.proxy.*
import dev.sapphire.service.ProxyForegroundService
import dev.sapphire.ui.screens.SapphireSettings
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.content.Intent
class MainViewModel(app: Application) : AndroidViewModel(app) {
    val state = SessionState()
    val stats = state.stats
    val logs  = state.logs
    private val commandEngine = CommandEngine(state)
    val commandOutput = commandEngine.output
    val settings = MutableStateFlow(SapphireSettings())
    var serverIp   = MutableStateFlow(""); var serverPort = MutableStateFlow("19132")
    private var proxy: BedrockProxy? = null; private val broadcaster = LanBroadcaster()
    fun connect() {
        val ip = serverIp.value.trim(); val port = serverPort.value.toIntOrNull() ?: 19132
        if (ip.isEmpty()) return
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            proxy = BedrockProxy(19132, ip, port, state).also { it.start() }
            broadcaster.apply { motd = settings.value.lanMotd }.start(viewModelScope)
        }
        val intent = Intent(getApplication(), ProxyForegroundService::class.java).apply {
            putExtra(ProxyForegroundService.EXTRA_IP, ip); putExtra(ProxyForegroundService.EXTRA_PORT, port)
        }
        getApplication<SapphireApp>().startForegroundService(intent)
    }
    fun disconnect() { proxy?.stop(); broadcaster.stop(); state.connected = false; state.updateStats() }
    fun sendCommand(cmd: String) { viewModelScope.launch { commandEngine.handle(cmd) } }
    override fun onCleared() { super.onCleared(); disconnect() }
}
