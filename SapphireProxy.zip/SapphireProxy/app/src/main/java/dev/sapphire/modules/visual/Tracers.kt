package dev.sapphire.modules.visual
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Tracers : Module("Tracers", Category.VISUAL, "Draw lines toward tracked entities") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}