package dev.sapphire.modules.world
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.*
class Scaffold : Module("Scaffold", Category.WORLD, "Auto-place blocks below while walking") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket && !packet.isOnGround) {
            val place = InventoryTransactionPacket().apply { transactionType = InventoryTransactionType.ITEM_USE; actions = mutableListOf() }
            return listOf(packet, place)
        }
        return listOf(packet)
    }
}