package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
class Fly : Module("Fly", Category.MOVEMENT, "Fly via position override", key = "fly") {
    var speed: Float = 0.8f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            packet.position = Vector3f.from(packet.position.x, packet.position.y + speed * 0.1f, packet.position.z)
            packet.isOnGround = false
        }
        return listOf(packet)
    }
}