package dev.sapphire.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import dev.sapphire.SapphireApp
import dev.sapphire.modules.ModuleManager
import dev.sapphire.proxy.BedrockProxy
import dev.sapphire.proxy.LanBroadcaster
import dev.sapphire.proxy.SessionState
import dev.sapphire.ui.MainActivity
import kotlinx.coroutines.*

class ProxyForegroundService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var proxy: BedrockProxy? = null
    private val broadcaster = LanBroadcaster()

    companion object {
        const val CHANNEL_ID  = "sapphire_proxy_channel"
        const val EXTRA_IP    = "server_ip"
        const val EXTRA_PORT  = "server_port"
        const val NOTIF_ID    = 1
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ip   = intent?.getStringExtra(EXTRA_IP)   ?: return START_NOT_STICKY
        val port = intent.getIntExtra(EXTRA_PORT, 19132)

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("💎 Sapphire Proxy")
            .setContentText("MITM relay active → $ip:$port")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setColorized(true)
            .setColor(0xFF2979FF.toInt())
            .setContentIntent(pendingIntent)
            .build()

        startForeground(NOTIF_ID, notification)

        val state = SessionState().apply {
            remoteHost = ip
            remotePort = port
        }

        scope.launch {
            proxy = BedrockProxy(19132, ip, port, state).also { it.start() }
            broadcaster.start(scope)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        proxy?.stop()
        broadcaster.stop()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "Sapphire Proxy Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps Bedrock MITM relay alive in background"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}
