package dev.sapphire.modules.player
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
import kotlin.math.sin
class AntiAFK : Module("AntiAFK", Category.MISC, "Rotate yaw to prevent AFK kick", key = "afk") {
    var intervalTicks: Int = 80; private var tick = 0L
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) { tick++; if (tick % intervalTicks == 0L) packet.yaw += (sin(tick * 0.1) * 15).toFloat() }
        return listOf(packet)
    }
}