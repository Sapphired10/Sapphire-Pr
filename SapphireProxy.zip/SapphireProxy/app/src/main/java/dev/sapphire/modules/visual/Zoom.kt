package dev.sapphire.modules.visual
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Zoom : Module("Zoom", Category.VISUAL, "FOV zoom via player property packet") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}