package dev.sapphire.modules.world
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class AutoPlace : Module("AutoPlace", Category.WORLD, "Auto-place blocks when looking at surface") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
}