package dev.sapphire.modules.player
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.RespawnState
import org.cloudburstmc.protocol.bedrock.packet.*
class AutoRespawn : Module("AutoRespawn", Category.PLAYER, "Auto-respawn on death") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}