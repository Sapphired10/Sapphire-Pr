package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
class Phase : Module("Phase", Category.MOVEMENT, "Pass through blocks via delta override") {
    var speed: Float = 0.5f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            packet.position = Vector3f.from(packet.position.x, packet.position.y, packet.position.z + speed)
        }
        return listOf(packet)
    }
}