package dev.sapphire.modules.visual
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class HitColor : Module("HitColor", Category.VISUAL, "Flash color on entity hit register") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}