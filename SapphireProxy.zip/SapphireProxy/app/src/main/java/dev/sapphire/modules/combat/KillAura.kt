package dev.sapphire.modules.combat
import dev.sapphire.SapphireApp
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.*
import kotlin.math.*
class KillAura : Module("KillAura", Category.COMBAT, "Auto-attack entities in range", key = "ka") {
    var range: Float = 4.5f; var multiTarget: Boolean = false; var rotateToTarget: Boolean = true
    private var playerPos = Vector3f.ZERO
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        val out = mutableListOf(packet)
        if (packet is PlayerAuthInputPacket) {
            playerPos = packet.position
            val targets = SapphireApp.entityTracker.getInRange(playerPos, range)
                .let { if (multiTarget) it.take(3) else listOfNotNull(it.firstOrNull()) }
            for (t in targets) {
                out.add(InventoryTransactionPacket().apply { transactionType = InventoryTransactionType.ITEM_USE_ON_ENTITY; actions = mutableListOf() })
                if (rotateToTarget) {
                    val dx = t.pos.x - playerPos.x; val dz = t.pos.z - playerPos.z; val dy = t.pos.y + 1.62f - playerPos.y
                    packet.yaw = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
                    packet.pitch = Math.toDegrees(atan2(-dy.toDouble(), sqrt((dx*dx+dz*dz).toDouble()))).toFloat()
                }
            }
        }
        return out
    }
}