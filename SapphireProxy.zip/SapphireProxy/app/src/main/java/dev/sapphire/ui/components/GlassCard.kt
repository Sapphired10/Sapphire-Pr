package dev.sapphire.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.sapphire.ui.theme.*
@Composable
fun GlassCard(modifier: Modifier = Modifier, cornerRadius: Dp = 16.dp, glowColor: Color = SapphirePrimary, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .shadow(8.dp, shape, ambientColor = glowColor.copy(0.25f), spotColor = glowColor.copy(0.15f))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(SapphireSurface.copy(0.93f), SapphireDeep.copy(0.97f))))
            .border(1.dp, Brush.linearGradient(listOf(glowColor.copy(0.5f), Color.Transparent, glowColor.copy(0.15f))), shape),
        content = content
    )
}
