package dev.sapphire.modules.combat
import dev.sapphire.SapphireApp
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
class Reach : Module("Reach", Category.COMBAT, "Extended hit range via position offset", key = "reach") {
    var range: Float = 6.0f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            val nearest = SapphireApp.entityTracker.getInRange(packet.position, range).firstOrNull()
            nearest?.let { t ->
                val dir = t.pos.subtract(packet.position).normalize()
                packet.position = packet.position.add(dir.mul(range - 4f))
            }
        }
        return listOf(packet)
    }
}