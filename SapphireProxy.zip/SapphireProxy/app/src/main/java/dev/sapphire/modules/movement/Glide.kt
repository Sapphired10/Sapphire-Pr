package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
class Glide : Module("Glide", Category.MOVEMENT, "Slow fall/glide mode") {
    var fallSpeed: Float = 0.02f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket && !packet.isOnGround) {
            packet.position = Vector3f.from(packet.position.x, packet.position.y - fallSpeed, packet.position.z)
        }
        return listOf(packet)
    }
}