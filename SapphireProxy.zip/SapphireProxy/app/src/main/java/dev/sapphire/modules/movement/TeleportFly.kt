package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
class TeleportFly : Module("TeleportFly", Category.MOVEMENT, "Jump-packet spoof fly bypass") {
    var stepHeight: Float = 0.42f; private var tick = 0; private var baseY = 0f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            if (tick == 0) baseY = packet.position.y; tick++
            packet.isOnGround = tick % 2 == 0
            packet.position = Vector3f.from(packet.position.x, baseY + tick * stepHeight * 0.08f, packet.position.z)
        }
        return listOf(packet)
    }
    override fun onDisable() { tick = 0 }
}