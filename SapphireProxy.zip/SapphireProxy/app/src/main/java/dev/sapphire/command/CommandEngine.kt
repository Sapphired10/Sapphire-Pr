package dev.sapphire.command

import dev.sapphire.SapphireApp
import dev.sapphire.proxy.SessionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Intercepts TextPacket messages starting with "/." and processes them as
 * internal Sapphire commands. The packet is DROPPED (never forwarded to server).
 *
 * Command format:  /.command [args...]
 * Examples:
 *   /.help                  — list all commands
 *   /.ka                    — toggle KillAura
 *   /.fly on                — enable Fly
 *   /.speed 2.0             — set Speed multiplier
 *   /.reach 5.5             — set Reach range
 *   /.modules               — list all modules + status
 *   /.status                — show proxy connection info
 *   /.log on                — enable packet log
 *   /.tp 100 64 200         — teleport to coords
 *   /.say <msg>             — send chat as server (inject TextPacket S→C)
 *   /.disconnect            — close upstream connection
 */
class CommandEngine(private val session: SessionState) {

    private val mgr = SapphireApp.moduleManager

    data class CommandResult(val message: String, val success: Boolean = true)

    private val _output = MutableStateFlow<List<String>>(emptyList())
    val output: StateFlow<List<String>> = _output

    /** @return null if not a command, result string if handled */
    fun handle(rawMessage: String): String? {
        if (!rawMessage.startsWith("/.")) return null
        val trimmed = rawMessage.removePrefix("/.")
        val parts   = trimmed.trim().split("\\s+".toRegex())
        val cmd     = parts.getOrElse(0) { "" }.lowercase()
        val args    = parts.drop(1)

        val result = when (cmd) {
            "help", "?"  -> helpText()
            "modules", "mods" -> moduleList()
            "status"     -> statusText()
            "toggle", "t" -> toggleModule(args)
            "on"         -> setModule(args, true)
            "off"        -> setModule(args, false)
            "speed"      -> setFloatParam("Speed",     "multiplier",   args, 0.1f, 20f)
            "reach"      -> setFloatParam("Reach",     "range",        args, 1f,   20f)
            "fly"        -> handleFly(args)
            "ka", "killaura" -> quickToggle("KillAura")
            "esp"        -> quickToggle("ESP")
            "fly2"       -> quickToggle("Fly")
            "nf", "nofall" -> quickToggle("NoFall")
            "vel", "velocity" -> quickToggle("Velocity")
            "sprint"     -> quickToggle("Sprint")
            "nuker"      -> quickToggle("Nuker")
            "fullbright", "fb" -> quickToggle("FullBright")
            "tp", "teleport" -> handleTeleport(args)
            "say"        -> handleSay(args)
            "log"        -> handleLog(args)
            "disconnect", "dc" -> handleDisconnect()
            "clear", "cls"  -> { clearLog(); "§7Log cleared." }
            "timer"      -> setFloatParam("Timer",     "multiplier",   args, 0.1f, 10f)
            "blink"      -> handleBlink(args)
            "surround"   -> quickToggle("Surround")
            "crash"      -> quickToggle("Crasher")
            "ib", "instabreak" -> quickToggle("InstaBreak")
            "aa", "aimassist"  -> quickToggle("AimAssist")
            "afk"        -> quickToggle("AntiAFK")
            "scaffold"   -> quickToggle("Scaffold")
            "crit"       -> quickToggle("Criticals")
            "desync"     -> quickToggle("Desync")
            "enuke"      -> quickToggle("EntityNuke")
            else         -> "§cUnknown command: §f/.$cmd §7— type §f/.help §7for a list"
        }

        pushOutput(result)
        return result
    }

    private fun helpText() = buildString {
        appendLine("§b§l──── Sapphire Proxy Commands ────")
        appendLine("§f/.help §7— this menu")
        appendLine("§f/.modules §7— list all modules")
        appendLine("§f/.status §7— proxy info")
        appendLine("§f/.ka / .esp / .fly / .nf / .vel §7— quick toggles")
        appendLine("§f/.speed <n> §7— set speed multiplier")
        appendLine("§f/.reach <n> §7— set reach range")
        appendLine("§f/.timer <n> §7— set timer multiplier")
        appendLine("§f/.tp <x> <y> <z> §7— teleport")
        appendLine("§f/.blink <ticks> §7— set blink duration")
        appendLine("§f/.say <message> §7— inject chat message")
        appendLine("§f/.log on|off §7— packet logger")
        appendLine("§f/.toggle <name> §7— toggle any module")
        appendLine("§f/.on / .off <name> §7— force enable/disable")
        appendLine("§f/.disconnect §7— drop proxy connection")
        append("§b§l──────────────────────────────────")
    }

    private fun moduleList() = buildString {
        appendLine("§b§l──── Modules ────")
        Module.Category.values().forEach { cat ->
            val mods = mgr.byCategory(cat)
            if (mods.isNotEmpty()) {
                append("§e${cat.emoji} ${cat.displayName}: ")
                appendLine(mods.joinToString("§7, ") { m ->
                    if (m.enabled) "§a${m.name}" else "§c${m.name}"
                })
            }
        }
        append("§7Active: §a${mgr.enabled.size}§7/§f${mgr.all.size}")
    }

    private fun statusText() = buildString {
        appendLine("§b§l──── Sapphire Proxy Status ────")
        appendLine("§7Connected: §f${if (session.connected) "§aYES" else "§cNO"}")
        appendLine("§7Server: §f${session.remoteHost}:${session.remotePort}")
        appendLine("§7Ping: §f${session.lastPingMs}ms")
        appendLine("§7Packets C→S: §f${session.ctsCount}")
        appendLine("§7Packets S→C: §f${session.stcCount}")
        appendLine("§7Active Modules: §a${mgr.enabled.joinToString("§7, §a") { it.name }}")
        append("§7LAN Broadcast: §f${if (session.lanActive) "§aLIVE" else "§cOFF"}")
    }

    private fun quickToggle(name: String): String {
        val on = mgr.toggle(name) ?: return "§cModule not found: §f$name"
        return if (on) "§a✔ §f$name §aenabled" else "§c✘ §f$name §cdisabled"
    }

    private fun toggleModule(args: List<String>): String {
        if (args.isEmpty()) return "§cUsage: §f/.toggle <module>"
        return quickToggle(args[0])
    }

    private fun setModule(args: List<String>, state: Boolean): String {
        if (args.isEmpty()) return "§cUsage: §f/.on <module> or /.off <module>"
        val m = mgr.get(args[0]) ?: return "§cModule not found: §f${args[0]}"
        if (m.enabled != state) m.toggle()
        return if (state) "§a✔ §f${m.name} §aforced on" else "§c✘ §f${m.name} §cforced off"
    }

    private fun setFloatParam(moduleName: String, field: String, args: List<String>, min: Float, max: Float): String {
        if (args.isEmpty()) return "§cUsage: §f/.${moduleName.lowercase()} <value>"
        val value = args[0].toFloatOrNull() ?: return "§cInvalid number: §f${args[0]}"
        if (value < min || value > max) return "§cValue out of range (§f$min§c–§f$max§c)"
        val m = mgr.get(moduleName) ?: return "§cModule not found: §f$moduleName"
        try {
            val f = m::class.java.getDeclaredField(field).also { it.isAccessible = true }
            f.setFloat(m, value)
            return "§a✔ §f${m.name}.$field §7set to §f$value"
        } catch (e: Exception) {
            return "§cFailed to set field: §f${e.message}"
        }
    }

    private fun handleFly(args: List<String>): String {
        val m = mgr.get("Fly") ?: return "§cFly module not found"
        return when (args.getOrNull(0)?.lowercase()) {
            "on"   -> { if (!m.enabled) m.toggle(); "§a✔ Fly enabled" }
            "off"  -> { if (m.enabled) m.toggle(); "§c✘ Fly disabled" }
            null   -> quickToggle("Fly")
            else   -> "§cUsage: §f/.fly [on|off]"
        }
    }

    private fun handleTeleport(args: List<String>): String {
        if (args.size < 3) return "§cUsage: §f/.tp <x> <y> <z>"
        val x = args[0].toFloatOrNull() ?: return "§cInvalid X"
        val y = args[1].toFloatOrNull() ?: return "§cInvalid Y"
        val z = args[2].toFloatOrNull() ?: return "§cInvalid Z"
        session.pendingTeleport = Triple(x, y, z)
        return "§a✔ Teleport queued to §f${x.toInt()}, ${y.toInt()}, ${z.toInt()}"
    }

    private fun handleSay(args: List<String>): String {
        if (args.isEmpty()) return "§cUsage: §f/.say <message>"
        val msg = args.joinToString(" ")
        session.pendingInjectChat = msg
        return "§a✔ Injected: §f$msg"
    }

    private fun handleLog(args: List<String>): String {
        val m = mgr.get("PacketLogger") ?: return "§cPacketLogger not found"
        return when (args.getOrNull(0)?.lowercase()) {
            "on"   -> { if (!m.enabled) m.toggle(); "§a✔ Packet log enabled" }
            "off"  -> { if (m.enabled) m.toggle(); "§c✘ Packet log disabled" }
            else   -> quickToggle("PacketLogger")
        }
    }

    private fun handleDisconnect(): String {
        session.requestDisconnect = true
        return "§c✘ Disconnecting..."
    }

    private fun handleBlink(args: List<String>): String {
        if (args.isEmpty()) return quickToggle("Blink")
        val ticks = args[0].toIntOrNull() ?: return "§cInvalid tick count"
        val m = mgr.get("Blink") ?: return "§cBlink not found"
        try {
            m::class.java.getDeclaredField("blinkDuration").also { it.isAccessible = true }.setInt(m, ticks)
        } catch (_: Exception) {}
        return "§a✔ Blink duration set to §f$ticks ticks"
    }

    private fun clearLog() {
        _output.value = emptyList()
    }

    private fun pushOutput(msg: String) {
        val current = _output.value.toMutableList()
        current.add(msg)
        if (current.size > 200) current.removeAt(0)
        _output.value = current
    }
}
