package dev.sapphire.modules.visual
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class ChestESP : Module("ChestESP", Category.VISUAL, "Highlight chests through walls") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}