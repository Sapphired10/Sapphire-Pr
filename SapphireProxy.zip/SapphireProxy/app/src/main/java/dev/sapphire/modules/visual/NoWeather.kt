package dev.sapphire.modules.visual
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class NoWeather : Module("NoWeather", Category.VISUAL, "Cancel rain/snow packets") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? {
        if (packet is LevelEventPacket && packet.type.name.contains("RAIN", ignoreCase = true)) return null
        return packet
    }
}