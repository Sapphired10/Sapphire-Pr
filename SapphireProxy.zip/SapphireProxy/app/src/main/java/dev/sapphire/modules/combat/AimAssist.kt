package dev.sapphire.modules.combat
import dev.sapphire.SapphireApp
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
import kotlin.math.*
class AimAssist : Module("AimAssist", Category.COMBAT, "Smooth rotation toward nearest player", key = "aa") {
    var range: Float = 6.0f; var smoothing: Float = 0.3f
    private var playerPos = Vector3f.ZERO
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            playerPos = packet.position
            val nearest = SapphireApp.entityTracker.getInRange(playerPos, range, playersOnly = true).firstOrNull()
            nearest?.let { t ->
                val dx = t.pos.x - playerPos.x; val dy = t.pos.y + 1.62f - playerPos.y; val dz = t.pos.z - playerPos.z
                val tYaw   = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
                val tPitch = Math.toDegrees(atan2(-dy.toDouble(), sqrt((dx*dx+dz*dz).toDouble()))).toFloat()
                packet.yaw   += (tYaw - packet.yaw) * smoothing
                packet.pitch += (tPitch - packet.pitch) * smoothing
            }
        }
        return listOf(packet)
    }
}