package dev.sapphire.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sapphire.command.CommandEngine
import dev.sapphire.ui.components.*
import dev.sapphire.ui.theme.*
import kotlinx.coroutines.flow.StateFlow
@Composable
fun CommandScreen(outputFlow: StateFlow<List<String>>, onCommand: (String) -> Unit) {
    val output by outputFlow.collectAsState()
    var input by remember { mutableStateOf("/.") }
    val listState = rememberLazyListState()
    val scope = kotlinx.coroutines.rememberCoroutineScope()
    LaunchedEffect(output.size) { if (output.isNotEmpty()) scope.launch { listState.animateScrollToItem(output.size - 1) } }
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("COMMAND CONSOLE", style = MaterialTheme.typography.titleMedium.copy(color = SapphireSecondary, letterSpacing = 2.sp, fontWeight = FontWeight.Bold))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("TYPE A COMMAND", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, letterSpacing = 2.sp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(input, { input = it }, Modifier.weight(1f),
                            placeholder = { Text("/.command", fontFamily = FontFamily.Monospace) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SapphirePrimary, unfocusedBorderColor = SapphireDivider, cursorColor = SapphireSecondary),
                            shape = RoundedCornerShape(12.dp), singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp))
                        IconButton(onClick = { if (input.startsWith("/.")) { onCommand(input); input = "/." } },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = SapphirePrimary.copy(0.15f))) {
                            Icon(Icons.Default.Send, null, tint = SapphirePrimary)
                        }
                    }
                }
            }
            Text("OUTPUT", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, letterSpacing = 2.sp))
            GlassCard(Modifier.fillMaxWidth().weight(1f)) {
                LazyColumn(state = listState, Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                    if (output.isEmpty()) item { Text("Type /.help to get started", style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace), color = TextMuted) }
                    items(output) { line ->
                        val color = when { line.startsWith("§a") -> SapphireSuccess; line.startsWith("§c") -> SapphireDanger; line.startsWith("§b") -> SapphireSecondary; else -> TextPrimary }
                        Text(line.replace(Regex("§[0-9a-fk-or]"), ""), style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp), color = color)
                    }
                }
            }
        }
    }
}
