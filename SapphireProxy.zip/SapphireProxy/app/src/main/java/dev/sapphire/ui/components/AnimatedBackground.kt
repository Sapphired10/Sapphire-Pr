package dev.sapphire.ui.components
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import dev.sapphire.ui.theme.*
import kotlin.math.sin
@Composable
fun AnimatedBackground(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, (2 * Math.PI).toFloat(), infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "t")
    Canvas(modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        fun orb(cx: Float, cy: Float, r: Float, color: Color) = drawCircle(
            brush = ShaderBrush(RadialGradientShader(Offset(cx, cy), r, listOf(color, SapphireDeep.copy(0f)))), radius = r, center = Offset(cx, cy))
        orb(w*0.2f+sin(t*0.7f)*w*0.15f, h*0.2f+sin(t*0.5f)*h*0.1f, w*0.5f, SapphirePrimary.copy(0.17f))
        orb(w*0.8f+sin(t*0.4f+1.2f)*w*0.12f, h*0.75f+sin(t*0.6f+0.8f)*h*0.1f, w*0.45f, SapphireAccentPurp.copy(0.13f))
        orb(w*0.5f+sin(t*0.3f+2.1f)*w*0.2f, h*0.5f+sin(t*0.45f+1.5f)*h*0.15f, w*0.35f, SapphireSecondary.copy(0.09f))
    }
}
