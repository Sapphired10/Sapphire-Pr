package dev.sapphire.modules.player
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class NameSpoof : Module("NameSpoof", Category.PLAYER, "Patch display name in login JWT") {
    var spoofedName: String = "Ghost"
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
}