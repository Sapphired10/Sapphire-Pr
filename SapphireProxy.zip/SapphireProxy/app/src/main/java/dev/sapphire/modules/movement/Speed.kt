package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Speed : Module("Speed", Category.MOVEMENT, "Multiply movement speed", key = "speed") {
    var multiplier: Float = 1.6f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            val d = packet.delta
            packet.delta = org.cloudburstmc.math.vector.Vector2f.from(d.x * multiplier, d.y * multiplier)
        }
        return listOf(packet)
    }
}