package dev.sapphire.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sapphire.ui.components.*
import dev.sapphire.ui.theme.*
data class SapphireSettings(val logPackets: Boolean = false, val lanMotd: String = "§bSapphire Proxy§r", val bypassAC: Boolean = true, val espOverlay: Boolean = false, val autoReconnect: Boolean = true)
@Composable
fun SettingsScreen(settings: SapphireSettings, onUpdate: (SapphireSettings) -> Unit) {
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("SETTINGS", style = MaterialTheme.typography.titleMedium.copy(color = SapphireSecondary, letterSpacing = 3.sp, fontWeight = FontWeight.Bold))
            SettingToggle("Log Packets", "Capture all packets in Logs tab", Icons.Default.BugReport, settings.logPackets) { onUpdate(settings.copy(logPackets = it)) }
            SettingToggle("AC Bypass Mode", "Smooth packet timing to reduce AC flags", Icons.Default.Security, settings.bypassAC) { onUpdate(settings.copy(bypassAC = it)) }
            SettingToggle("Auto Reconnect", "Reconnect on connection drop", Icons.Default.Refresh, settings.autoReconnect) { onUpdate(settings.copy(autoReconnect = it)) }
            SettingToggle("ESP Overlay", "Draw ESP on SYSTEM_ALERT_WINDOW", Icons.Default.Layers, settings.espOverlay) { onUpdate(settings.copy(espOverlay = it)) }
            GlassCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LAN BROADCAST NAME", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, letterSpacing = 2.sp))
                    OutlinedTextField(settings.lanMotd, { onUpdate(settings.copy(lanMotd = it)) }, Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SapphirePrimary, unfocusedBorderColor = SapphireDivider),
                        shape = RoundedCornerShape(12.dp))
                }
            }
            GlassCard(glowColor = SapphireDanger.copy(0.4f)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ABOUT", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, letterSpacing = 2.sp))
                    Text("Sapphire Proxy v2.0", style = MaterialTheme.typography.titleMedium.copy(color = TextPrimary, fontWeight = FontWeight.Bold))
                    Text("Minecraft Bedrock MITM Client", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Text("PS4 / PS5 / Android / iOS / Console via LAN", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                }
            }
        }
    }
}
@Composable
private fun SettingToggle(title: String, subtitle: String, icon: ImageVector, checked: Boolean, onToggle: (Boolean) -> Unit) {
    GlassCard {
        Row(Modifier.padding(16.dp).fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = SapphirePrimary, modifier = Modifier.size(22.dp))
                Column { Text(title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)); Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary) }
            }
            NeonSwitch(checked = checked, onCheckedChange = onToggle)
        }
    }
}
