package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class IceSpeed : Module("IceSpeed", Category.MOVEMENT, "Maintain speed on ice tiles") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
}