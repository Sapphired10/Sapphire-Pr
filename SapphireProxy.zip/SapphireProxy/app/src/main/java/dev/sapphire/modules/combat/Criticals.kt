package dev.sapphire.modules.combat
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.*
class Criticals : Module("Criticals", Category.COMBAT, "Spoof fall state for full crit damage", key = "crit") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) packet.inputData.add(PlayerAuthInputData.JUMPING)
        return listOf(packet)
    }
}