package dev.sapphire.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val SapphireColorScheme = darkColorScheme(
    primary          = SapphirePrimary,
    onPrimary        = Color.White,
    primaryContainer = Color(0xFF1565C0),
    secondary        = SapphireSecondary,
    onSecondary      = Color.Black,
    tertiary         = SapphireAccentPurp,
    background       = SapphireDeep,
    onBackground     = TextPrimary,
    surface          = SapphireSurface,
    onSurface        = TextPrimary,
    surfaceVariant   = SapphireElevated,
    outline          = SapphireDivider,
    error            = SapphireDanger,
)
@Composable
fun SapphireTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SapphireColorScheme, typography = SapphireTypography, content = content)
}
