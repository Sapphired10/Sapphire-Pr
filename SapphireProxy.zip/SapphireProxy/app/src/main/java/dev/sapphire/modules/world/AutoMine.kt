package dev.sapphire.modules.world
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class AutoMine : Module("AutoMine", Category.WORLD, "Auto-break targeted block continuously") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
}