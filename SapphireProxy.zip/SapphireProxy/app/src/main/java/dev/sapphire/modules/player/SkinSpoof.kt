package dev.sapphire.modules.player
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class SkinSpoof : Module("SkinSpoof", Category.PLAYER, "Replace outbound skin data") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
}