package dev.sapphire.modules.combat
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class AutoArmor : Module("AutoArmor", Category.COMBAT, "Auto-equip best armor from inventory") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)
}