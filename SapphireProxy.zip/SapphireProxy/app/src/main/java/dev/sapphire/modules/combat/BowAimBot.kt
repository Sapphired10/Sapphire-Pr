package dev.sapphire.modules.combat
import dev.sapphire.SapphireApp
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
import kotlin.math.*
class BowAimBot : Module("BowAimBot", Category.COMBAT, "Auto-aim bow at nearest player", key = "bow") {
    var range: Float = 30f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            val t = SapphireApp.entityTracker.getInRange(packet.position, range, playersOnly = true).firstOrNull()
            t?.let {
                val dx = it.pos.x - packet.position.x; val dy = it.pos.y + 1f - packet.position.y; val dz = it.pos.z - packet.position.z
                packet.yaw   = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
                packet.pitch = Math.toDegrees(atan2(-dy.toDouble(), sqrt((dx*dx+dz*dz).toDouble()))).toFloat()
            }
        }
        return listOf(packet)
    }
}