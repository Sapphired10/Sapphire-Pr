package dev.sapphire.modules.combat
import dev.sapphire.SapphireApp
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class AntiBot : Module("AntiBot", Category.COMBAT, "Filter bots from KillAura targets") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}