package dev.sapphire.proxy

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Shared mutable state — proxy writes, UI reads, command engine writes */
class SessionState {
    // Connection
    var connected: Boolean = false
    var remoteHost: String = ""
    var remotePort: Int = 19132
    var lanActive: Boolean = false

    // Stats
    var ctsCount: Long = 0L
    var stcCount: Long = 0L
    var lastPingMs: Long = 0L

    // Pending ops set by CommandEngine, consumed by SessionManager each tick
    @Volatile var pendingTeleport: Triple<Float, Float, Float>? = null
    @Volatile var pendingInjectChat: String? = null
    @Volatile var requestDisconnect: Boolean = false

    // Reactive log entries for UI
    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs

    fun pushLog(entry: LogEntry) {
        val cur = _logs.value.toMutableList()
        cur.add(entry)
        if (cur.size > 500) cur.removeAt(0)
        _logs.value = cur
    }

    fun clearLogs() { _logs.value = emptyList() }

    // Reactive stats flow for HomeScreen
    private val _stats = MutableStateFlow(ProxyStats())
    val stats: StateFlow<ProxyStats> = _stats

    fun updateStats() {
        _stats.value = ProxyStats(connected, ctsCount, stcCount, lastPingMs, lanActive)
    }
}

data class ProxyStats(
    val connected: Boolean = false,
    val ctsPackets: Long = 0L,
    val stcPackets: Long = 0L,
    val pingMs: Long = 0L,
    val lanActive: Boolean = false
)

data class LogEntry(
    val direction: String,
    val packetName: String,
    val info: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
