package dev.sapphire.proxy

import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.packet.*
import java.util.concurrent.ConcurrentHashMap

data class TrackedEntity(
    val runtimeId: Long,
    val uniqueId: Long,
    val name: String,
    var pos: Vector3f,
    var yaw: Float = 0f,
    var pitch: Float = 0f,
    val isPlayer: Boolean,
    val entityType: String = "unknown"
)

class EntityTracker {
    private val _entities = ConcurrentHashMap<Long, TrackedEntity>()
    val entities: Map<Long, TrackedEntity> get() = _entities

    fun handle(packet: Any) {
        when (packet) {
            is AddPlayerPacket      -> _entities[packet.runtimeEntityId] = TrackedEntity(
                runtimeId = packet.runtimeEntityId,
                uniqueId  = packet.uniqueEntityId,
                name      = packet.username,
                pos       = packet.position,
                yaw       = packet.rotation.y,
                pitch     = packet.rotation.x,
                isPlayer  = true,
                entityType = "player"
            )
            is AddEntityPacket      -> _entities[packet.runtimeEntityId] = TrackedEntity(
                runtimeId  = packet.runtimeEntityId,
                uniqueId   = packet.uniqueEntityId,
                name       = packet.identifier,
                pos        = packet.position,
                isPlayer   = false,
                entityType = packet.identifier
            )
            is MoveEntityAbsolutePacket -> _entities[packet.runtimeEntityId]?.let {
                it.pos   = packet.position
                it.yaw   = packet.rotation.y
                it.pitch = packet.rotation.x
            }
            is MoveEntityDeltaPacket -> _entities[packet.runtimeEntityId]?.let { e ->
                e.pos = Vector3f.from(
                    e.pos.x + packet.x,
                    e.pos.y + packet.y,
                    e.pos.z + packet.z
                )
            }
            is MovePlayerPacket -> _entities[packet.runtimeEntityId]?.let {
                it.pos   = packet.position
                it.yaw   = packet.rotation.y
                it.pitch = packet.rotation.x
            }
            is RemoveEntityPacket -> _entities.remove(packet.uniqueEntityId)
            is SetEntityDataPacket -> { /* nametag updates — optional */ }
        }
    }

    fun getInRange(origin: Vector3f, range: Float, playersOnly: Boolean = false): List<TrackedEntity> =
        _entities.values.filter { e ->
            (!playersOnly || e.isPlayer) &&
            e.pos.distanceSquared(origin) <= range * range
        }.sortedBy { it.pos.distanceSquared(origin) }

    fun clear() = _entities.clear()
}
