package dev.sapphire.ui.components
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import dev.sapphire.ui.theme.*
@Composable
fun NeonSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit, activeColor: Color = SapphireSuccess, modifier: Modifier = Modifier) {
    val trackColor by animateColorAsState(if (checked) activeColor.copy(0.3f) else SapphireDivider, tween(250), label = "t")
    val thumbColor by animateColorAsState(if (checked) activeColor else TextMuted, tween(250), label = "th")
    val thumbOff by animateFloatAsState(if (checked) 1f else 0f, spring(0.6f, 400f), label = "o")
    val inf = rememberInfiniteTransition(label = "p")
    val glow by inf.animateFloat(0.4f, 0.8f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "g")
    Box(modifier.width(48.dp).height(28.dp).clip(RoundedCornerShape(14.dp)).background(trackColor)
        .border(1.dp, if (checked) activeColor.copy(0.6f) else Color.Transparent, RoundedCornerShape(14.dp))
        .clickable { onCheckedChange(!checked) }, Alignment.CenterStart) {
        Box(Modifier.padding(start = (4f + thumbOff * 20f).dp).size(20.dp)
            .shadow(if (checked) 6.dp else 0.dp, CircleShape, ambientColor = thumbColor.copy(glow), spotColor = thumbColor.copy(glow))
            .clip(CircleShape).background(thumbColor))
    }
}
