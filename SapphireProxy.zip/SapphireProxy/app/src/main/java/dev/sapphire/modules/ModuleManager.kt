package dev.sapphire.modules

import dev.sapphire.modules.combat.*
import dev.sapphire.modules.movement.*
import dev.sapphire.modules.visual.*
import dev.sapphire.modules.world.*
import dev.sapphire.modules.player.*
import dev.sapphire.modules.misc.*
import dev.sapphire.modules.exploit.*

class ModuleManager {
    val all: List<Module> = listOf(
        // ── COMBAT ─────────────────────────────────────────────
        KillAura(),
        AimAssist(),
        Criticals(),
        Velocity(),
        Reach(),
        AutoClicker(),
        Surround(),
        AntiBot(),
        BowAimBot(),
        AutoArmor(),
        // ── MOVEMENT ───────────────────────────────────────────
        Speed(),
        Fly(),
        NoFall(),
        Sprint(),
        Blink(),
        Phase(),
        HighJump(),
        LongJump(),
        TeleportFly(),
        Glide(),
        Strafe(),
        IceSpeed(),
        // ── VISUAL ─────────────────────────────────────────────
        ESP(),
        Tracers(),
        FullBright(),
        ChestESP(),
        NoWeather(),
        Zoom(),
        HitColor(),
        // ── WORLD ──────────────────────────────────────────────
        Nuker(),
        AutoMine(),
        Scaffold(),
        InstaBreak(),
        AutoPlace(),
        ChestStealer(),
        // ── PLAYER ─────────────────────────────────────────────
        AntiAFK(),
        AutoEat(),
        AutoRespawn(),
        NameSpoof(),
        SkinSpoof(),
        // ── MISC ───────────────────────────────────────────────
        Spammer(),
        PacketLogger(),
        Crasher(),
        // ── EXPLOIT ────────────────────────────────────────────
        Timer(),
        Desync(),
        EntityNuke()
    )

    val enabled: List<Module> get() = all.filter { it.enabled }

    fun toggle(name: String): Boolean? {
        val m = get(name) ?: return null
        return m.toggle()
    }

    fun get(name: String): Module? =
        all.firstOrNull { it.name.equals(name, ignoreCase = true) || it.key.equals(name, ignoreCase = true) }

    fun byCategory(cat: Module.Category): List<Module> = all.filter { it.category == cat }

    fun tickAll() = enabled.forEach { it.onTick() }
}
