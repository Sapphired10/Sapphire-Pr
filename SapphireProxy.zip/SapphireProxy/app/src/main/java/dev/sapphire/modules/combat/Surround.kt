package dev.sapphire.modules.combat
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.*
class Surround : Module("Surround", Category.COMBAT, "Place blocks on 4 sides defensively", key = "surround") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            val p = packet.position; val base = Vector3i.from(p.x.toInt(), (p.y-1).toInt(), p.z.toInt())
            val sides = listOf(Vector3i.from(base.x+1,base.y,base.z),Vector3i.from(base.x-1,base.y,base.z),Vector3i.from(base.x,base.y,base.z+1),Vector3i.from(base.x,base.y,base.z-1))
            val extras = sides.map { InventoryTransactionPacket().apply { transactionType = InventoryTransactionType.ITEM_USE; actions = mutableListOf() } }
            return listOf(packet) + extras
        }
        return listOf(packet)
    }
}