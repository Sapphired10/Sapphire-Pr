package dev.sapphire.modules.world
import dev.sapphire.modules.Module
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.PlayerActionType
import org.cloudburstmc.protocol.bedrock.packet.*
class Nuker : Module("Nuker", Category.WORLD, "Break blocks in radius per tick") {
    var radius: Int = 3; var breakDelay: Int = 1; private var tick = 0
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            tick++; if (tick % breakDelay.coerceAtLeast(1) != 0) return listOf(packet)
            val p = packet.position; val base = Vector3i.from(p.x.toInt(), (p.y-1).toInt(), p.z.toInt())
            val out = mutableListOf<BedrockPacket>(packet)
            for (x in -radius..radius) for (y in -1..radius) for (z in -radius..radius) {
                if (x*x+y*y+z*z <= radius*radius) {
                    out.add(PlayerActionPacket().apply { action = PlayerActionType.START_BREAK; blockPosition = Vector3i.from(base.x+x,base.y+y,base.z+z); face = 1 })
                }
            }
            return out
        }
        return listOf(packet)
    }
}