package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Strafe : Module("Strafe", Category.MOVEMENT, "Boost strafe speed") {
    var boost: Float = 1.4f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            val d = packet.delta
            packet.delta = org.cloudburstmc.math.vector.Vector2f.from(d.x * boost, d.y)
        }
        return listOf(packet)
    }
}