package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class NoFall : Module("NoFall", Category.MOVEMENT, "Force onGround=true to negate fall damage", key = "nf") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is MovePlayerPacket) packet.isOnGround = true
        if (packet is PlayerAuthInputPacket) packet.isOnGround = true
        return listOf(packet)
    }
}