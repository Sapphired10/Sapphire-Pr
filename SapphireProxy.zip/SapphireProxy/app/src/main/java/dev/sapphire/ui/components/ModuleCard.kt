package dev.sapphire.ui.components
import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sapphire.modules.Module
import dev.sapphire.ui.theme.*
@Composable
fun ModuleCard(module: Module, onToggle: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    val catColor = when (module.category) {
        Module.Category.COMBAT   -> SapphireDanger
        Module.Category.MOVEMENT -> SapphirePrimary
        Module.Category.VISUAL   -> SapphireSecondary
        Module.Category.WORLD    -> SapphireWarning
        Module.Category.PLAYER   -> SapphireSuccess
        Module.Category.MISC     -> SapphireAccentPurp
        Module.Category.EXPLOIT  -> Color(0xFFFF6D00)
    }
    GlassCard(glowColor = if (module.enabled) catColor else Color.Transparent, modifier = modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(16.dp, 12.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(module.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold, color = if (module.enabled) catColor else TextPrimary))
                    Text(module.description, style = MaterialTheme.typography.bodyMedium, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                    if (module.key.isNotEmpty()) Text("/.${module.key}", style = MaterialTheme.typography.labelSmall, color = TextMuted.copy(0.7f))
                }
                NeonSwitch(checked = module.enabled, onCheckedChange = onToggle, activeColor = catColor)
            }
            AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Column(Modifier.padding(top = 10.dp)) {
                    Divider(color = SapphireDivider, thickness = 0.5.dp)
                    Spacer(Modifier.height(8.dp))
                    module.settingsContent()
                }
            }
        }
    }
}
