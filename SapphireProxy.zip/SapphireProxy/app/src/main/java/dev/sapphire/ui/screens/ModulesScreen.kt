package dev.sapphire.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sapphire.modules.Module
import dev.sapphire.modules.ModuleManager
import dev.sapphire.ui.components.*
import dev.sapphire.ui.theme.*
@Composable
fun ModulesScreen(manager: ModuleManager) {
    val cats = Module.Category.values()
    var sel by remember { mutableStateOf(0) }
    var rev by remember { mutableStateOf(0) }
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize()) {
            ScrollableTabRow(sel, containerColor = SapphireDeep.copy(0.96f), contentColor = SapphirePrimary, edgePadding = 16.dp,
                indicator = { tabs -> TabRowDefaults.Indicator(Modifier.tabIndicatorOffset(tabs[sel]), 2.dp, SapphirePrimary) }) {
                cats.forEachIndexed { i, cat ->
                    val cc = when(cat) { Module.Category.COMBAT -> SapphireDanger; Module.Category.MOVEMENT -> SapphirePrimary; Module.Category.VISUAL -> SapphireSecondary; Module.Category.WORLD -> SapphireWarning; Module.Category.EXPLOIT -> androidx.compose.ui.graphics.Color(0xFFFF6D00); else -> SapphireAccentPurp }
                    Tab(i == sel, { sel = i }, text = { Text("${cat.emoji} ${cat.displayName}", fontSize = 11.sp, letterSpacing = 0.8.sp, fontWeight = if (i == sel) FontWeight.Bold else FontWeight.Normal, color = if (i == sel) cc else TextMuted) })
                }
            }
            key(rev) {
                val filtered = manager.all.filter { it.category == cats[sel] }
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(top = 14.dp, bottom = 32.dp)) {
                    items(filtered, key = { it.name }) { mod ->
                        ModuleCard(mod, { manager.toggle(mod.name); rev++ })
                    }
                }
            }
        }
    }
}
