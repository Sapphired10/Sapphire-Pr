package dev.sapphire

import android.app.Application
import dev.sapphire.modules.ModuleManager
import dev.sapphire.proxy.EntityTracker

class SapphireApp : Application() {
    companion object {
        lateinit var instance: SapphireApp
            private set
        val moduleManager = ModuleManager()
        val entityTracker = EntityTracker()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
