package dev.sapphire.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.sapphire.proxy.LogEntry
import dev.sapphire.ui.components.*
import dev.sapphire.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun LogsScreen(logs: List<LogEntry>, onClear: () -> Unit) {
    var filter by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) scope.launch { listState.animateScrollToItem(logs.size - 1) } }
    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text("PACKET LOGS", style = MaterialTheme.typography.titleMedium.copy(color = SapphireSecondary, letterSpacing = 2.sp, fontWeight = FontWeight.Bold))
                IconButton(onClick = onClear) { Icon(Icons.Default.Delete, null, tint = SapphireDanger) }
            }
            OutlinedTextField(filter, { filter = it }, Modifier.fillMaxWidth(), placeholder = { Text("Filter packets...") },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = SapphirePrimary) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SapphirePrimary, unfocusedBorderColor = SapphireDivider),
                shape = RoundedCornerShape(12.dp), singleLine = true)
            val filtered = if (filter.isEmpty()) logs else logs.filter { it.packetName.contains(filter, true) || it.info.contains(filter, true) }
            Text("${filtered.size} packets", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
            LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                items(filtered) { e ->
                    val color = when(e.direction) { "C→S" -> SapphirePrimary; "S→C" -> SapphireSecondary; else -> SapphireWarning }
                    GlassCard(glowColor = color.copy(0.25f)) {
                        Row(Modifier.padding(10.dp, 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(e.direction, color = color, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(e.packetName, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            if (e.info.isNotEmpty()) Text(e.info, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
