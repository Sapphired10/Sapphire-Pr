package dev.sapphire.modules.world
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class ChestStealer : Module("ChestStealer", Category.WORLD, "Auto-loot items from opened containers") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}