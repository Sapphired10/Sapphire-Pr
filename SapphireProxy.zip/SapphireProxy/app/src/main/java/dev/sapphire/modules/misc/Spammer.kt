package dev.sapphire.modules.misc
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class Spammer : Module("Spammer", Category.MISC, "Inject chat messages on interval") {
    var message: String = "Sapphire Proxy"; var intervalTicks: Int = 100; private var tick = 0
    override fun onTick() {
        tick++; if (tick % intervalTicks == 0) tick = 0
    }
}