package dev.sapphire.modules.visual
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class FullBright : Module("FullBright", Category.VISUAL, "Force daytime for max brightness", key = "fb") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? {
        if (packet is SetTimePacket) packet.time = 6000
        return packet
    }
}