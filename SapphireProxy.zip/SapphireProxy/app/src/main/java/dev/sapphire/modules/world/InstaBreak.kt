package dev.sapphire.modules.world
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.PlayerActionType
import org.cloudburstmc.protocol.bedrock.packet.*
class InstaBreak : Module("InstaBreak", Category.WORLD, "Instant break via START+STOP pair", key = "ib") {
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerActionPacket && packet.action == PlayerActionType.START_BREAK) {
            val stop = PlayerActionPacket().apply { action = PlayerActionType.ABORT_BREAK; blockPosition = packet.blockPosition; face = packet.face }
            return listOf(packet, stop)
        }
        return listOf(packet)
    }
}