package dev.sapphire.modules.player
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.packet.*
class AutoEat : Module("AutoEat", Category.PLAYER, "Auto-eat food when hunger is low") {
    override fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet
}