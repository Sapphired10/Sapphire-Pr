package dev.sapphire.modules.combat
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.*
class AutoClicker : Module("AutoClicker", Category.COMBAT, "Rapid attack packets per tick", key = "ac") {
    var cps: Int = 20; private var tick = 0
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket) {
            tick++
            if (tick % (20 / cps.coerceIn(1, 20)) == 0) {
                return listOf(packet, InventoryTransactionPacket().apply { transactionType = InventoryTransactionType.ITEM_USE_ON_ENTITY; actions = mutableListOf() })
            }
        }
        return listOf(packet)
    }
}