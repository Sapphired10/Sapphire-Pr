package dev.sapphire.modules

import androidx.compose.runtime.Composable
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket

abstract class Module(
    val name: String,
    val category: Category,
    val description: String,
    var enabled: Boolean = false,
    var key: String = ""   // chat trigger alias e.g. "ka" for KillAura → "/.ka"
) {
    enum class Category(val displayName: String, val emoji: String) {
        COMBAT("Combat", "⚔️"),
        MOVEMENT("Movement", "🏃"),
        VISUAL("Visual", "👁️"),
        WORLD("World", "🌍"),
        PLAYER("Player", "🧍"),
        MISC("Misc", "🔧"),
        EXPLOIT("Exploit", "💥")
    }

    // C→S: return empty list to drop the packet, or modified list
    open fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> = listOf(packet)

    // S→C: return null to drop the packet from reaching client
    open fun onServerToClient(packet: BedrockPacket): BedrockPacket? = packet

    // Called once per tick (driven by PlayerAuthInputPacket arrival)
    open fun onTick() {}

    // Called when module is toggled on
    open fun onEnable() {}

    // Called when module is toggled off
    open fun onDisable() {}

    // Compose UI for settings panel — override to add sliders/inputs
    @Composable
    open fun settingsContent() {}

    fun toggle(): Boolean {
        enabled = !enabled
        if (enabled) onEnable() else onDisable()
        return enabled
    }
}
