package dev.sapphire.modules.movement
import dev.sapphire.modules.Module
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.*
class LongJump : Module("LongJump", Category.MOVEMENT, "Extend horizontal jump distance") {
    var distance: Float = 3.0f
    override fun onClientToServer(packet: BedrockPacket): List<BedrockPacket> {
        if (packet is PlayerAuthInputPacket && packet.inputData.contains(PlayerAuthInputData.JUMPING)) {
            val d = packet.delta
            packet.delta = org.cloudburstmc.math.vector.Vector2f.from(d.x * distance, d.y)
        }
        return listOf(packet)
    }
}